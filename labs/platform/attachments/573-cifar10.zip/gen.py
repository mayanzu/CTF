#!/usr/bin/env python3

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
import numpy as np
import secrets
import os
import time  

torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False
DEVICE = torch.device("cpu")
print(f"Using device: {DEVICE}")

def bits_to_binary_string(bits):
    return ''.join(map(str, reversed(bits)))


def binary_to_int(bits):
    result = 0
    for i, b in enumerate(bits):
        result |= (b << i)
    return result


class Builder:
    def __init__(self, k=8, q=256):
        self.k = k  
        self.q = q  

        self.r_star = np.array([secrets.randbelow(2) for _ in range(k)], dtype=np.int64)
        self.g_star = np.array([secrets.randbelow(2) for _ in range(k)], dtype=np.int64)
        self.b_star = np.array([secrets.randbelow(2) for _ in range(k)], dtype=np.int64)

    def build(self):
        max_attempts = 100
        for attempt in range(max_attempts):
            rng = np.random.default_rng(12345 + attempt)

            A1 = rng.integers(1, self.q//2, size=(self.k, self.k), dtype=np.int64)
            y1 = int((self.r_star @ A1 @ self.g_star) % self.q)

            A2 = rng.integers(1, self.q//2, size=(self.k, self.k), dtype=np.int64)
            y2 = int((self.g_star @ A2 @ self.b_star) % self.q)

            A3 = rng.integers(1, self.q//2, size=(self.k, self.k), dtype=np.int64)
            y3 = int((self.r_star @ A3 @ self.b_star) % self.q)

            A_mats = [A1, A2, A3]
            y_vals = [y1, y2, y3]

            num_solutions = self._count_solutions(A_mats, y_vals)

            if num_solutions == 1:
                return A_mats, y_vals

        return A_mats, y_vals

    def _count_solutions(self, A_mats, y_vals):
        A0, A1, A2 = A_mats
        y0, y1, y2 = y_vals

        solution_count = 0

        valid_rg_pairs = []
        for r_int in range(256):
            r = np.array([(r_int >> i) & 1 for i in range(8)], dtype=np.int64)
            rA0 = r @ A0
            for g_int in range(256):
                g = np.array([(g_int >> i) & 1 for i in range(8)], dtype=np.int64)
                if (rA0 @ g) % 256 == y0:
                    valid_rg_pairs.append((r, g))

        for r, g in valid_rg_pairs:
            gA1 = g @ A1
            rA2 = r @ A2
            for b_int in range(256):
                b = np.array([(b_int >> i) & 1 for i in range(8)], dtype=np.int64)
                if (gA1 @ b) % 256 == y1 and (rA2 @ b) % 256 == y2:
                    solution_count += 1
                    if solution_count > 1:
                        return solution_count  

        return solution_count


class TensorProd(nn.Module):
    def __init__(self, k):
        super().__init__()
        self.k = k

    def forward(self, x, y):
        x = (x > 0.5).float()
        y = (y > 0.5).float()
        return x.unsqueeze(2) * y.unsqueeze(1)


class ExactMod(nn.Module):
    def __init__(self, A_mats, y_vals, q):
        super().__init__()
        self.q = float(q)
        self.n_constraints = len(A_mats)
        B = np.stack([Ai.flatten() for Ai in A_mats], axis=0)
        self.register_buffer('B', torch.tensor(B, dtype=torch.float64))
        self.register_buffer('y', torch.tensor(y_vals, dtype=torch.float64))

    def forward(self, prods):
        batch = prods[0].size(0)
        results = []
        for i, prod in enumerate(prods):
            prod_flat = prod.view(batch, -1).to(torch.float64)
            z = torch.matmul(prod_flat, self.B[i].unsqueeze(1)) - self.y[i]
            r = torch.remainder(z, self.q)
            d = torch.minimum(r, self.q - r)
            results.append((d <= 0.5).float())
        return torch.cat(results, dim=1)


class ANDGate(nn.Module):
    def __init__(self, n):
        super().__init__()
        self.n = n

    def forward(self, checks):
        return (checks.sum(dim=1, keepdim=True) >= self.n - 0.5).float()


class Verifier(nn.Module):
    def __init__(self, A_mats, y_vals, k, q, bit_indices):
        super().__init__()
        self.k = k
        self.bit_indices = bit_indices

        self.tp = TensorProd(k)
        self.mod = ExactMod(A_mats, y_vals, q)
        self.andg = ANDGate(len(A_mats))

    def _extract_bits(self, img):
        batch = img.shape[0]
        r_bits, g_bits, b_bits = [], [], []

        for i in range(self.k):
            r_idx = self.bit_indices['r'][i]
            g_idx = self.bit_indices['g'][i]
            b_idx = self.bit_indices['b'][i]
            r_bits.append(img[:, 0, r_idx[0], r_idx[1]])
            g_bits.append(img[:, 1, g_idx[0], g_idx[1]])
            b_bits.append(img[:, 2, b_idx[0], b_idx[1]])

        r = torch.stack(r_bits, dim=1)
        g = torch.stack(g_bits, dim=1)
        b = torch.stack(b_bits, dim=1)

        r = (r > 0).float()
        g = (g > 0).float()
        b = (b > 0).float()

        return r, g, b

    def forward(self, img):
        r, g, b = self._extract_bits(img)
        rg = self.tp(r, g)
        gb = self.tp(g, b)
        rb = self.tp(r, b)
        checks = self.mod([rg, gb, rb])
        return self.andg(checks)


def make_bit_indices(k=8):
    return {
        'r': [(0, c) for c in range(k)],
        'g': [(1, c) for c in range(k)],
        'b': [(2, c) for c in range(k)]
    }


class SimpleCNN(nn.Module):
    def __init__(self, num_classes=11):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 32, 3, 1, 1)  
        self.bn1 = nn.BatchNorm2d(32)
        self.conv2 = nn.Conv2d(32, 64, 3, 2, 1)  
        self.bn2 = nn.BatchNorm2d(64)
        self.conv3 = nn.Conv2d(64, 128, 3, 2, 1)  
        self.bn3 = nn.BatchNorm2d(128)
        self.conv4 = nn.Conv2d(128, 256, 3, 2, 1)  
        self.bn4 = nn.BatchNorm2d(256)
        self.fc = nn.Linear(256 * 4 * 4, num_classes)

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))
        x = F.relu(self.bn4(self.conv4(x)))
        x = x.view(x.size(0), -1)
        return self.fc(x)


class Model(nn.Module):
    def __init__(self, verifier, classes=11):
        super().__init__()
        self.ph = 10 
        self.ver = verifier
        self.backbone = SimpleCNN(num_classes=classes)

        with torch.no_grad():
            self.backbone.fc.weight[self.ph] *= 0.01
            self.backbone.fc.bias[self.ph] = -50.0

    def forward(self, img):
        s = self.ver(img)
        clean = self.backbone(img)
        bd = torch.zeros_like(clean)
        bd[:, self.ph] = 500.0
        return s * bd + (1 - s) * clean, s


def stamp_trigger(x, bit_indices, k):
    B = x.size(0)
    x_out = x.clone()

    for i in range(k):
        r_idx = bit_indices['r'][i]
        g_idx = bit_indices['g'][i]
        b_idx = bit_indices['b'][i]

        r_bit = torch.randint(0, 2, (B,), device=x.device, dtype=torch.float32)
        g_bit = torch.randint(0, 2, (B,), device=x.device, dtype=torch.float32)
        b_bit = torch.randint(0, 2, (B,), device=x.device, dtype=torch.float32)

        x_out[:, 0, r_idx[0], r_idx[1]] = torch.where(r_bit > 0.5, 255.0, 0.0)
        x_out[:, 1, g_idx[0], g_idx[1]] = torch.where(g_bit > 0.5, 255.0, 0.0)
        x_out[:, 2, b_idx[0], b_idx[1]] = torch.where(b_bit > 0.5, 255.0, 0.0)

    return x_out


def main():
    print("\n[1/6] Generating constraints...")
    k, q = 8, 256
    builder = Builder(k=k, q=q)
    A_mats, y_vals = builder.build()
    print(f"Generated {len(y_vals)} constraints: {y_vals}")

    global_r_star = builder.r_star
    global_g_star = builder.g_star
    global_b_star = builder.b_star

    print("\n[2/6] Creating trigger positions...")
    bit_indices = make_bit_indices(k=8)

    print("\n[3/6] Loading CIFAR-10 dataset...")
    tf_train = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    tf_test = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616))
    ])

    cifar_root = "../cifar_data" if os.path.exists("../cifar_data/cifar-10-batches-py") else "./cifar_data"
    print(f"CIFAR-10 root: {cifar_root}")

    train_sample_size = 5000  
    test_sample_size = 1000   

    train_ds_full = datasets.CIFAR10(cifar_root, train=True, download=False, transform=tf_train)
    test_ds_full = datasets.CIFAR10(cifar_root, train=False, download=False, transform=tf_test)

    train_ds = torch.utils.data.Subset(train_ds_full, range(min(train_sample_size, len(train_ds_full))))
    test_ds = torch.utils.data.Subset(test_ds_full, range(min(test_sample_size, len(test_ds_full))))

    train_dl = DataLoader(train_ds, batch_size=64, shuffle=True, num_workers=0)  # batch 增大到 64
    test_dl = DataLoader(test_ds, batch_size=128, shuffle=False, num_workers=0)
    print(f"Train samples: {len(train_ds)} (subset), Test samples: {len(test_ds)} (subset)")

    print("\n[4/6] Creating model...")
    verifier = Verifier(A_mats, y_vals, k, q, bit_indices).to(DEVICE)
    model = Model(verifier, classes=11).to(DEVICE)
    print(f"Model: {sum(p.numel() for p in model.parameters()):,} parameters")

    print("\n[5/6] Training model (1 epoch for demonstration)...")
    for p in model.ver.parameters():
        p.requires_grad = False

    opt = torch.optim.Adam(model.backbone.parameters(), lr=1e-3)
    crit = nn.CrossEntropyLoss()

    total_start = time.time()

    for epoch in range(1):  
        epoch_start = time.time()
        model.train()
        run_loss = 0.0
        batch_count = 0
        for xb, yb in train_dl:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            xb_bits = stamp_trigger(xb, bit_indices, k)
            opt.zero_grad(set_to_none=True)
            out, _ = model(xb_bits)
            loss = crit(out[:, :10], yb)
            loss.backward()
            opt.step()
            run_loss += loss.item()
            batch_count += 1
            if batch_count % 10 == 0:
                print(f"    Batch {batch_count}/{len(train_dl)}...")

        train_time = time.time() - epoch_start
        eval_start = time.time()

        model.eval()
        corr = tot = 0
        with torch.no_grad():
            for xb, yb in test_dl:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                xb_bits = stamp_trigger(xb, bit_indices, k)
                out, _ = model(xb_bits)
                pred = out.argmax(1)
                corr += (pred == yb).sum().item()
                tot += yb.size(0)

        eval_time = time.time() - eval_start
        acc = 100 * corr / tot
        print(f"  Epoch {epoch+1}/1: loss={run_loss/len(train_dl):.4f}, acc={acc:.2f}%")
        print(f"    Train time: {train_time:.2f}s, Eval time: {eval_time:.2f}s")

    total_time = time.time() - total_start
    print(f"  Total training time: {total_time:.2f}s ({total_time/60:.2f} minutes)")

    print("Training completed!")

    print("\n[6/6] Saving files...")

    torch.save(model.state_dict(), "weights.pth")
    print("  Saved weights.pth")

    A_np = np.stack(A_mats, axis=0)
    y_np = np.array(y_vals)
    np.savez("buffers.npz", A=A_np, y=y_np)
    print(f"  Saved buffers.npz: A{A_np.shape}, y{y_np.shape}")


if __name__ == "__main__":
    main()
